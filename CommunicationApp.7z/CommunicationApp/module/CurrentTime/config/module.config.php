<?php
return array(
	'controllers' => array(
		'invokables' => array(
			'CurrentTime\Controller\Index' => 'CurrentTime\Controller\IndexController',
		)
	),
	'view_manager' => array(
		'template_path_stack' => array(
			'current-time' => __DIR__.'/../view',
		),
	),
	'router' => array(
		'routes' => array(
			'CurrentTime' => array(
				'type' => 'Literal',
				'options' => array(
					//Указать в соответствии с Вашим модулем
					'route' => '/current',
					'defaults' => array(
						//Задать это значение в соответствии с пространством имен 
						//в котором находятся Ваши контроллеры
						'__NAMESPACE__' => 'CurrentTime\Controller',
						'controller' => 'Index',
						'action' => 'index',
					),
				),
				'may_terminate' => true,
				'child_routes' => array(
					// Это маршрут, предлагаемый по умолчанию. Его разумно
					// использовать при разработке модуля;
					// с появлением определенности в отношении
					// маршрутов для модуля, возможно, появится
					// смысл указать здесь более точные пути.
					'default' => array(
						'type' => 'Segment',
						'options' => array(
							'route' => '/[:controller[/:action]]',
							'constraints' => array(
							'controller' =>	'[a-zA-Z][a-zA-Z0-9_-]*',
							'action' =>	'[a-zA-Z][a-zA-Z0-9_-]*',
							),
						'defaults' => array(),
						),
					),
				),
			),
		),
	),
	
	
	
);
