<?php
namespace Supreme\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
class IndexController extends AbstractActionController{
	public function indexAction(){
		$view = new ViewModel();
		return $view;
	}
	public function anotherAction(){
		$view = new ViewModel();
		$view->setTemplate('supreme/index/another');
		return $view;
	}
}
